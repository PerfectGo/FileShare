$(document).ready(function () {
    var percent = $('#topicComments').attr('percent');
    var columnId = $('#topicComments').attr('columnId');
    var topicId = $('#topicComments').attr('topicid');
    if (!percent) percent = 0;
    try {
        percent = parseInt(percent)
    } catch (error) {
        percent = 0
    }
    var max = percent;
    var lastMax = percent;
    var commentToTop = (getElementTop(document.getElementById('topicContainer')) - $(window).height()) * 0.9;
    var getMax = function () {
        return commentToTop * 0.9;
    }
    if(percent == 10){
        $(document).scrollTop(0);
    }else{
        let scrollTop = $('#topicContainer').height() * percent / 10;
        $(document).scrollTop(scrollTop);
    }
    setInterval(function () {
        var road = max - lastMax;
        if (max > 10) max = 10;
        if (max != lastMax && road < 8 && max < 11) {
            lastMax = max;
            var url = '/m/mazi/rpi';
            $.ajax({
                url: url,
                type: 'post',
                data: {
                    columnTopicId: topicId,
                    columnId: columnId,
                    percent: max
                },
                dataType: 'json',
                success: function (data, status) {
                    if (data.code === 0) {
                    } else {
                        console.log('update error')
                    }
                }
            });
        } else {
            var position = $(window).scrollTop();
            max = parseInt(parseInt((position / commentToTop) * 10));
            if (max > 10) max = 10;    
        }
    }, 3000)
    var getValue = function () {
        var position = $(window).scrollTop();
        var temp = parseInt(parseInt((position / commentToTop) * 10));
        if (temp > 10) temp =10;
        if (temp > max) max = temp;
        return position;
    }

    function getElementTop(element) {
        return element.offsetTop + element.clientHeight;
    }
    if ('max' in document.createElement('progress')) {
        // Browser supports progress element
        var progressBar = $('progress');

        // Set the Max attr for the first time
        progressBar.attr({ max: getMax() });

        $(document).on('scroll', function () {
            // On scroll only Value attr needs to be calculated
            progressBar.attr({ value: getValue() });
        });

        $(window).resize(function () {
            // On resize, both Max/Value attr needs to be calculated
            progressBar.attr({ max: getMax(), value: getValue() });
        });
    }
    else {
        var progressBar = $('.progress-bar'),
            max = getMax(),
            value, width;

        var getWidth = function () {
            // Calculate width in percentage
            value = getValue();
            width = (value / max) * 100;
            width = width + '%';
            return width;
        }

        var setWidth = function () {
            progressBar.css({ width: getWidth() });
        }

        $(document).on('scroll', setWidth);
        $(window).on('resize', function () {
            // Need to reset the Max attr
            max = getMax();
            setWidth();
        });
    }
});


$(document).ready(function () {

    $('#flat').addClass("active");
    $('#progressBar').addClass('flat');


    $(document).on('scroll', function () {

        maxAttr = $('#progressBar').attr('max');
        valueAttr = $('#progressBar').attr('value');
        percentage = (valueAttr / maxAttr) * 100;

        if (percentage < 49) {
            $("#progressBar").removeClass('flat2');
            $("#progressBar").removeClass('flat1');
            $('#progressBar').addClass('flat');
        }
        else if (percentage < 98 && percentage > 49) {
            $("#progressBar").removeClass('flat');
            $("#progressBar").removeClass('flat2');
            $('#progressBar').addClass('flat1');
        }
        else {
            $("#progressBar").removeClass('flat');
            $("#progressBar").removeClass('flat1');
            $('#progressBar').addClass('flat2');
        }
    });

});